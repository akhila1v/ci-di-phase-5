package com.phase5.springboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
